<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Categorylist</name>
   <tag></tag>
   <elementGuidId>1c24f7ab-8568-4be4-b73a-2b93f3ca6dbf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>025a1e5d-cc8f-42b7-8506-59efdac201be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>1884b446-47f2-4742-a0d3-8d5035b0fccf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>ad8d4091-b000-425f-9954-93fae8b41881</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>k+fyIAyB82R9jVEmroQ0OWwSW3A=</value>
      <webElementGuid>ae20a02b-e2a6-441b-84e6-8a853e56374c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>00f74e87-f96c-4935-9674-40ef46d3d8a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>378ad509-a61a-4ecc-a078-70cfad3c77e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>e3893551-37ad-435a-b364-11a0715508f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>8ab3f31f-9558-497f-a894-3f177dd9109f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>006cbe26-6c8e-4f24-b379-91a4cd0c2823</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys' Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls' Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men's Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women's Fashion
    </value>
      <webElementGuid>f5720623-f752-41c0-94b3-becfe4535637</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>3dc436fe-0741-47d0-ad87-71ae3aebfb96</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>7b06f39c-1d44-464d-a91b-b57aa15c5de0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>861fed86-0c3a-4a8d-90c5-10fcb2454cfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>3cf2eb37-3ff7-41d2-8f6c-4a35101a85b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;) or . = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;))]</value>
      <webElementGuid>c121fcf3-4e43-4266-90f9-151e43e970d8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
